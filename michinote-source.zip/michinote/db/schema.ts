import { sqliteTable, text, integer, real, index } from 'drizzle-orm/sqlite-core';
export const rides=sqliteTable('rides',{
 id:text('id').primaryKey(),userId:text('user_id').notNull(),title:text('title').notNull(),date:text('date').notNull(),bike:text('bike').notNull().default(''),note:text('note').notNull().default(''),points:text('points').notNull(),distance:real('distance').notNull(),source:text('source').notNull(),createdAt:text('created_at').notNull(),token:text('token'),hideMeters:integer('hide_meters').notNull().default(800),sharePhotos:integer('share_photos').notNull().default(0)
},t=>[index('rides_user').on(t.userId,t.date),index('rides_token').on(t.token)]);
export const photos=sqliteTable('photos',{
 id:text('id').primaryKey(),userId:text('user_id').notNull(),rideId:text('ride_id').notNull().references(()=>rides.id,{onDelete:'cascade'}),key:text('key').notNull(),caption:text('caption').notNull().default(''),lat:real('lat').notNull(),lng:real('lng').notNull(),createdAt:text('created_at').notNull()
},t=>[index('photos_ride').on(t.rideId)]);
