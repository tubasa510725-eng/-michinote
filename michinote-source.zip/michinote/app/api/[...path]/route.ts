import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {distance,validPoint,mask,safePoint, type Point} from '../../../lib/geo';
export const dynamic='force-dynamic';
const json=(d:unknown,status=200)=>Response.json(d,{status,headers:{'Cache-Control':'private, no-store'}});
function fail(message:string,status=400):never{throw Object.assign(new Error(message),{status})}
const db=()=>{if(!env.DB)fail('記録を読み込めません。少し待って再試行してください。',503);return env.DB!};
const query=(sql:string,...args:unknown[])=>db().prepare(sql).bind(...args);
const clean=(r:any)=>({...r,points:JSON.parse(r.points),share_photos:!!r.share_photos});
async function body(req:Request){const raw=await req.text();if(raw.length>1500000)fail('記録が大きすぎます。GPXは12000地点以内にしてください。',413);try{return JSON.parse(raw)}catch{fail('入力内容を読み込めません。')}}
async function handle(req:Request){const url=new URL(req.url),path=url.pathname.split('/').filter(Boolean).slice(1),user=await getChatGPTUser();
 if(req.method!=='GET'&&req.headers.get('origin')!==url.origin)fail('このページから操作してください。',403);
 if(path[0]==='shared'&&path[1]&&req.method==='GET'){
  const r:any=await query('SELECT * FROM rides WHERE token = ?',path[1]).first();if(!r)fail('招待状が見つからないか、公開が終了しています。',404);const points:Point[]=JSON.parse(r.points),lines=mask(points,r.hide_meters);const pics:any=await query('SELECT id,caption,lat,lng FROM photos WHERE ride_id = ?',r.id).all();
  return json({ride:{id:r.id,title:r.title,date:r.date,bike:r.bike,note:r.note,lines,points:lines.flat(),distance:lines.reduce((n,line)=>n+distance(line),0),source:r.source,photos:r.share_photos?pics.results.filter((p:any)=>safePoint(p,points,r.hide_meters)).map((p:any)=>({...p,url:`/api/photo/${p.id}?token=${path[1]}`})):[]}});
 }
 if(path[0]==='photo'&&path[1]&&req.method==='GET'){
  const p:any=await query('SELECT photos.*,rides.token,rides.points,rides.hide_meters,rides.share_photos FROM photos JOIN rides ON rides.id=photos.ride_id WHERE photos.id = ?',path[1]).first();if(!p)fail('写真が見つかりません。',404);
  const token=url.searchParams.get('token');if(p.user_id!==user?.userId&&!(token&&token===p.token&&p.share_photos&&safePoint(p,JSON.parse(p.points),p.hide_meters)))fail('写真が見つかりません。',404);
  const object=await env.BUCKET?.get(p.key);if(!object)fail('写真が見つかりません。',404);return new Response(object.body,{headers:{'Content-Type':'image/jpeg','Cache-Control':'private,no-store','X-Content-Type-Options':'nosniff'}});
 }
 if(!user)fail('ログインしてから記録してください。',401);
 if(path[0]==='rides'&&!path[1]&&req.method==='GET'){
  const rows=await query('SELECT * FROM rides WHERE user_id = ? ORDER BY date DESC,created_at DESC',user.userId).all();const pics=await query('SELECT id,ride_id,caption,lat,lng FROM photos WHERE user_id = ? ORDER BY created_at',user.userId).all();return json({rides:rows.results.map((r:any)=>({...clean(r),photos:pics.results.filter((p:any)=>p.ride_id===r.id).map((p:any)=>({...p,url:'/api/photo/'+p.id}))}))});
 }
 if(path[0]==='rides'&&!path[1]&&req.method==='POST'){
  const data=await body(req);if(!Array.isArray(data.points)||data.points.length<2||data.points.length>12000||!data.points.every(validPoint))fail('2〜12000地点のルートが必要です。');if(!data.title?.trim()||data.title.length>80||String(data.note||'').length>2000||String(data.bike||'').length>60)fail('タイトルは80文字、メモは2000文字以内で入力してください。');if(!/^\d{4}-\d{2}-\d{2}$/.test(data.date)||!Number.isFinite(Date.parse(data.date))||new Date(data.date).toISOString().slice(0,10)!==data.date||data.date>new Date(Date.now()+9*3600000).toISOString().slice(0,10))fail('訪問日を今日以前の日付で入力してください。');
  const points=data.points.map((p:any)=>({lat:p.lat,lng:p.lng,...(p.time&&Number.isFinite(Date.parse(p.time))?{time:p.time}:{})}));const id=crypto.randomUUID();await query('INSERT INTO rides (id,user_id,title,date,bike,note,points,distance,source,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',id,user.userId,data.title.trim(),data.date,String(data.bike||''),String(data.note||''),JSON.stringify(points),distance(points),['gpx','gps','manual'].includes(data.source)?data.source:'manual',new Date().toISOString()).run();return json({id},201);
 }
 if(path[0]==='rides'&&path[1]){
  const r:any=await query('SELECT * FROM rides WHERE id = ? AND user_id = ?',path[1],user.userId).first();if(!r)fail('記録が見つかりません。',404);
  if(req.method==='DELETE'&&!path[2]){const pics=await query('SELECT key FROM photos WHERE ride_id = ?',r.id).all();await db().batch([query('DELETE FROM photos WHERE ride_id = ?',r.id),query('DELETE FROM rides WHERE id = ? AND user_id = ?',r.id,user.userId)]);for(const p of pics.results)await env.BUCKET?.delete(String(p.key));return json({ok:true})}
  if(path[2]==='share'&&req.method==='POST'){const data=await body(req),meters=Number(data.hideMeters);if(![300,800,1500,3000].includes(meters))fail('隠す範囲を選んでください。');const token=data.enabled?(r.token||crypto.randomUUID()+crypto.randomUUID()):null;await query('UPDATE rides SET token = ?,hide_meters = ?,share_photos = ? WHERE id = ? AND user_id = ?',token,meters,+!!data.photos,r.id,user.userId).run();return json({token})}
  if(path[2]==='photos'&&req.method==='POST'){
   if(Number(req.headers.get('content-length')||0)>6000000)fail('写真は5MB以内にしてください。',413);const form=await req.formData(),file=form.get('photo');if(!(file instanceof File)||file.size>5000000||file.size===0)fail('5MB以内の写真を選んでください。');const bytes=new Uint8Array(await file.arrayBuffer());if(bytes[0]!==255||bytes[1]!==216||bytes[2]!==255)fail('JPEG写真を選んでください。');const lat=Number(form.get('lat')),lng=Number(form.get('lng'));if(!validPoint({lat,lng}))fail('写真の場所を地図で選んでください。');const caption=String(form.get('caption')||'');if(caption.length>300)fail('写真のメモは300文字以内です。');if(!env.BUCKET)fail('写真を保存できません。',503);const id=crypto.randomUUID(),key=`photos/${user.userId}/${id}.jpg`;await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:'image/jpeg'}});try{await query('INSERT INTO photos (id,user_id,ride_id,key,caption,lat,lng,created_at) VALUES (?,?,?,?,?,?,?,?)',id,user.userId,r.id,key,caption,lat,lng,new Date().toISOString()).run()}catch(e){await env.BUCKET.delete(key);throw e}return json({id},201);
  }
 }
 fail('ページが見つかりません。',404);
}
async function handler(req:Request){try{return await handle(req)}catch(e:any){console.error('michinote',e.status||500,e.message);return json({error:e.status?e.message:'通信に失敗しました。もう一度お試しください。'},e.status||503)}}
export {handler as GET,handler as POST,handler as DELETE};
