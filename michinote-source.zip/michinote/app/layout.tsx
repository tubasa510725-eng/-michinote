import type {Metadata} from 'next';
import './globals.css';
import 'leaflet/dist/leaflet.css';
export const metadata:Metadata={title:'ミチノート｜走った道が、次の旅になる',description:'バイクの旅を白地図に。走った道と写真を残し、次の旅を見つけるツーリングノート。',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ja"><body>{children}</body></html>}
