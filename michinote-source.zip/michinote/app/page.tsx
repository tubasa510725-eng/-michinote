import Michinote from './michinote';
export default function Home(){return <Michinote/>}
