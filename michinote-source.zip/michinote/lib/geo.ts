export type Point={lat:number;lng:number;time?:string};
export function km(a:Point,b:Point){const r=Math.PI/180,dy=(b.lat-a.lat)*r,dx=(b.lng-a.lng)*r,h=Math.sin(dy/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dx/2)**2;return 6371*2*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)))}
export function distance(p:Point[]){return p.slice(1).reduce((s,v,i)=>s+km(p[i],v),0)}
export function safePoint(p:Point,points:Point[],meters:number){return points.length>1&&km(p,points[0])*1000>=meters&&km(p,points[points.length-1])*1000>=meters}
export function mask(points:Point[],meters:number){const lines:Point[][]=[];let line:Point[]=[];for(const p of points){if(safePoint(p,points,meters))line.push(p);else if(line.length){if(line.length>1)lines.push(line);line=[]}}if(line.length>1)lines.push(line);return lines}
export function validPoint(p:unknown):p is Point{const v=p as Point;return !!v&&Number.isFinite(v.lat)&&Number.isFinite(v.lng)&&Math.abs(v.lat)<=85&&Math.abs(v.lng)<=180}
