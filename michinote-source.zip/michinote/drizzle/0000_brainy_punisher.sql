CREATE TABLE `photos` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`ride_id` text NOT NULL,
	`key` text NOT NULL,
	`caption` text DEFAULT '' NOT NULL,
	`lat` real NOT NULL,
	`lng` real NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`ride_id`) REFERENCES `rides`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `photos_ride` ON `photos` (`ride_id`);--> statement-breakpoint
CREATE TABLE `rides` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`title` text NOT NULL,
	`date` text NOT NULL,
	`bike` text DEFAULT '' NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`points` text NOT NULL,
	`distance` real NOT NULL,
	`source` text NOT NULL,
	`created_at` text NOT NULL,
	`token` text,
	`hide_meters` integer DEFAULT 800 NOT NULL,
	`share_photos` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `rides_user` ON `rides` (`user_id`,`date`);--> statement-breakpoint
CREATE INDEX `rides_token` ON `rides` (`token`);